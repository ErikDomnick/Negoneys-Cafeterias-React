/*mostra uma reserva, nome e data no formato dia/mes/ano, pessoa ou pessoas piá e os botões editar e remover.*/

import styles from "./ItemReserva.module.css";

function ItemReserva({ reserva, aoEditar, aoRemover }) {
  //split eh a tesoura, ele corta onde tiver o "-", exemplo a questão da data 2026-11-09
  //o reverse ele vai inverter, ent vai ficar 09 11 e 2026
  // o join serve como uma cola aq, ele pega os valores que forma cortados e invertidos e junta td e coloca uma / na divisão, ou seja fica assim: 09/11/2026
  const dataBr = reserva.data.split("-").reverse().join("/");
  return (
    <li className={styles["item"]}>
      <div className={styles["info"]}>
        <strong className={styles["nome"]}>{reserva.nome}</strong>
        <span className={styles["detalhe"]}>
          {dataBr} - {reserva.pessoas} {reserva.pessoas === 1 ? "pessoa" : "pessoas"}
        </span>
      </div>

      <div className={styles["botoes"]}>
        <button className={styles["botao"]} onClick={() => aoEditar(reserva)}>
          Editar
        </button>
        <button className={styles["botao"]} onClick={() => aoRemover(reserva.id)}>
          Remover
        </button>
      </div>
    </li>
  );
}

export default ItemReserva;